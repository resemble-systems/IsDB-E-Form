/* tslint:disable */
require("./ContractForm.module.css");
const styles = {
  contractForm: 'contractForm_d0d51719',
  teams: 'teams_d0d51719',
  welcome: 'welcome_d0d51719',
  welcomeImage: 'welcomeImage_d0d51719',
  links: 'links_d0d51719'
};

export default styles;
/* tslint:enable */