/* tslint:disable */
require("./ContractForm.module.css");
const styles = {
  announcementsFilterInput: 'announcementsFilterInput_56a60e77'
};

export default styles;
/* tslint:enable */