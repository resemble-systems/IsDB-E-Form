/* tslint:disable */
require("./PrintVisitForm.module.css");
const styles = {
  printVisitForm: 'printVisitForm_1fe5e4f3',
  teams: 'teams_1fe5e4f3',
  welcome: 'welcome_1fe5e4f3',
  welcomeImage: 'welcomeImage_1fe5e4f3',
  links: 'links_1fe5e4f3'
};

export default styles;
/* tslint:enable */